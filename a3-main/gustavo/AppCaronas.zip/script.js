document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const mobileNav = document.querySelector('.mobile-nav');
    const searchButton = document.querySelector('.search-button'); // Botão da index.html

    if (menuToggle && mobileNav) {
        menuToggle.addEventListener('click', function() {
            mobileNav.classList.toggle('active');
            const icon = menuToggle.querySelector('i');
            if (mobileNav.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
                menuToggle.setAttribute('aria-label', 'Fechar menu');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
                menuToggle.setAttribute('aria-label', 'Abrir menu');
            }
        });
    }

    // MUDANÇA AQUI para o botão "PROCURAR CARONA" da index.html
    if (searchButton) {
        searchButton.addEventListener('click', function() {
            // alert('Funcionalidade de busca de carona a ser implementada!'); // Linha antiga
            window.location.href = 'procurar_carona.html'; // Nova ação: redirecionar
        });
    }

    // Opcional: Fechar o menu mobile se clicar fora dele
    document.addEventListener('click', function(event) {
        if (mobileNav && mobileNav.classList.contains('active')) { // Verifica se mobileNav existe e está ativo
            const isClickInsideNav = mobileNav.contains(event.target);
            const isClickOnToggle = menuToggle && menuToggle.contains(event.target); // Verifica se menuToggle existe

            if (!isClickInsideNav && !isClickOnToggle) {
                mobileNav.classList.remove('active');
                if (menuToggle) { // Verifica se menuToggle existe antes de manipular seu ícone
                    const icon = menuToggle.querySelector('i');
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                    menuToggle.setAttribute('aria-label', 'Abrir menu');
                }
            }
        }
    });
});